import Error from "../../components/Error/Error"

export default function ErrorPage () {
    return (
        <Error />
    )
}