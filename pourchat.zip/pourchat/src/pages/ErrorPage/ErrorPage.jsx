import Error from "../../components/Banner/Error/Error"

export default function ErrorPage () {
    return (
        <Error />
    )
}