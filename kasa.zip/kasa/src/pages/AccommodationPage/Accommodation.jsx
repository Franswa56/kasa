import Carrousel from "../../components/Carrousel/Carrousel";
import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import logements from "../../assets/logements.json";


export default function Accomodation() {
    const params = useParams();
    const navigate = useNavigate();

    const [pickedAppart, setPickedAppart] = useState();

    useEffect(() => {
        const picked = logements.find(({ id }) => id === params.id);
        if (picked) {
            setPickedAppart(picked);
        } else {
            navigate("/404", { state: { message: "Logement non trouvé" } });
        }
    }, [params.id, navigate]);

    return (
        pickedAppart && (
            <div className="fiche-container">
                <Carrousel slides={pickedAppart.pictures} />
            </div>
        )
    );
}